# Sample data for initial load when no CSV is uploaded
SAMPLE_PLAYERS = [
    {"player_id": "P00001", "player_name": "Kylian Griezmann", "team": "France", "nationality": "French", "position": "Goalkeeper", "age": 24, "height_cm": 191, "weight_kg": 81, "market_value_eur": 16574124, "matches_played": 34, "total_goals": 0, "total_assists": 0, "avg_pass_accuracy": 0.73, "avg_rating": 2.33, "top_speed_kmh": 30.3, "tournament_rating": 7.4, "avg_performance_score": 23.83},
    {"player_id": "P00002", "player_name": "Antoine Tchouameni", "team": "France", "nationality": "French", "position": "Goalkeeper", "age": 29, "height_cm": 190, "weight_kg": 84, "market_value_eur": 53959475, "matches_played": 34, "total_goals": 0, "total_assists": 0, "avg_pass_accuracy": 0.73, "avg_rating": 1.96, "top_speed_kmh": 32.8, "tournament_rating": 7.5, "avg_performance_score": 20.32},
    {"player_id": "P00003", "player_name": "Ousmane Hernandez", "team": "France", "nationality": "French", "position": "Goalkeeper", "age": 24, "height_cm": 191, "weight_kg": 77, "market_value_eur": 4935397, "matches_played": 34, "total_goals": 0, "total_assists": 0, "avg_pass_accuracy": 0.71, "avg_rating": 2.04, "top_speed_kmh": 32.1, "tournament_rating": 7.3, "avg_performance_score": 21.75},
    {"player_id": "P00004", "player_name": "Kylian Camavinga", "team": "France", "nationality": "French", "position": "Defender", "age": 27, "height_cm": 183, "weight_kg": 80, "market_value_eur": 3795900, "matches_played": 34, "total_goals": 0, "total_assists": 0, "avg_pass_accuracy": 0.81, "avg_rating": 3.47, "top_speed_kmh": 37.0, "tournament_rating": 7.3, "avg_performance_score": 35.86},
    {"player_id": "P00005", "player_name": "Antoine Kounde", "team": "France", "nationality": "French", "position": "Defender", "age": 24, "height_cm": 188, "weight_kg": 79, "market_value_eur": 21832889, "matches_played": 34, "total_goals": 0, "total_assists": 2, "avg_pass_accuracy": 0.82, "avg_rating": 4.27, "top_speed_kmh": 35.8, "tournament_rating": 8.2, "avg_performance_score": 43.15},
    {"player_id": "P00006", "player_name": "Ousmane Upamecano", "team": "France", "nationality": "French", "position": "Defender", "age": 25, "height_cm": 185, "weight_kg": 74, "market_value_eur": 3260134, "matches_played": 34, "total_goals": 0, "total_assists": 0, "avg_pass_accuracy": 0.82, "avg_rating": 3.64, "top_speed_kmh": 35.6, "tournament_rating": 7.2, "avg_performance_score": 36.51},
    {"player_id": "P00007", "player_name": "Aurelien Rabiot", "team": "France", "nationality": "French", "position": "Defender", "age": 25, "height_cm": 184, "weight_kg": 76, "market_value_eur": 21875188, "matches_played": 34, "total_goals": 1, "total_assists": 1, "avg_pass_accuracy": 0.81, "avg_rating": 3.46, "top_speed_kmh": 34.8, "tournament_rating": 7.8, "avg_performance_score": 34.83},
    {"player_id": "P00008", "player_name": "Eduardo Sissoko", "team": "France", "nationality": "French", "position": "Defender", "age": 22, "height_cm": 176, "weight_kg": 76, "market_value_eur": 3056356, "matches_played": 34, "total_goals": 0, "total_assists": 1, "avg_pass_accuracy": 0.83, "avg_rating": 3.98, "top_speed_kmh": 35.9, "tournament_rating": 7.0, "avg_performance_score": 40.33},
]

SAMPLE_TEAMS = [
    {"team": "France", "matches": 34, "goals_for": 53, "goals_against": 50, "wins": 12, "draws": 11, "losses": 11, "squad_size": 8, "avg_rating": 3.58},
    {"team": "Germany", "matches": 34, "goals_for": 38, "goals_against": 40, "wins": 11, "draws": 9, "losses": 14, "squad_size": 8, "avg_rating": 3.64},
]

SAMPLE_OVERVIEW = {
    "total_players": 8,
    "total_teams": 2,
    "total_matches": 34,
    "total_goals": 91,
    "avg_age": 25.5
}

STAGE_GOALS = {"Final": 63, "Group Stage": 1535, "Quarter Finals": 200, "Round of 16": 344, "Round of 32": 478, "Semi Finals": 126, "Third Place Match": 48}
POSITION_ORDER = ["Goalkeeper", "Defender", "Midfielder", "Forward"]