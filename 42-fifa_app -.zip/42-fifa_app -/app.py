from flask import Flask, render_template, request, jsonify
import pandas as pd
import json
from data.sample_data import SAMPLE_PLAYERS, SAMPLE_TEAMS, SAMPLE_OVERVIEW, STAGE_GOALS, POSITION_ORDER

app = Flask(__name__)

# Global data stores
players = SAMPLE_PLAYERS.copy()
teams = SAMPLE_TEAMS.copy()
overview = SAMPLE_OVERVIEW.copy()
stage_goals = STAGE_GOALS.copy()


def process_csv_data(df):
    """Process uploaded CSV and convert to the expected data format"""
    required_cols = ['player_name', 'team', 'position']
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Group by player (aggregate match-level data)
    player_cols = ['player_id', 'player_name', 'team', 'nationality', 'position', 
                   'age', 'height_cm', 'weight_kg', 'market_value_eur']
    
    # Get base player info
    if 'player_id' not in df.columns:
        df['player_id'] = df.apply(lambda r: f"P_{r['player_name']}_{r['team']}", axis=1)
    
    # Aggregate numeric fields
    agg_dict = {
        'total_goals': 'sum',
        'total_assists': 'sum',
        'matches_played': 'count',
        'avg_pass_accuracy': 'mean',
        'avg_rating': 'mean',
        'tournament_rating': 'mean',
        'avg_performance_score': 'mean',
        'top_speed_kmh': 'max',
        'age': 'first',
        'height_cm': 'first',
        'weight_kg': 'first',
        'market_value_eur': 'first'
    }
    
    # Only aggregate columns that exist
    agg_dict = {k: v for k, v in agg_dict.items() if k in df.columns}
    
    grouped = df.groupby(['player_id', 'player_name', 'team', 'position']).agg(agg_dict).reset_index()
    
    # Fill missing values
    for col in ['player_name', 'team', 'position', 'nationality']:
        if col not in grouped.columns:
            grouped[col] = ''
    
    # Convert to list of dicts
    players_list = grouped.to_dict('records')
    
    # Process teams
    teams_df = df.groupby('team').agg({
        'match_id': 'nunique',
        'goals_team': 'sum' if 'goals_team' in df.columns else 'count',
        'goals_opponent': 'sum' if 'goals_opponent' in df.columns else 'count',
    }).reset_index()
    
    teams_df.columns = ['team', 'matches', 'goals_for', 'goals_against']
    
    if 'match_result' in df.columns:
        wins = df[df['match_result'] == 'W'].groupby('team').size()
        draws = df[df['match_result'] == 'D'].groupby('team').size()
        losses = df[df['match_result'] == 'L'].groupby('team').size()
        teams_df['wins'] = teams_df['team'].map(wins).fillna(0).astype(int)
        teams_df['draws'] = teams_df['team'].map(draws).fillna(0).astype(int)
        teams_df['losses'] = teams_df['team'].map(losses).fillna(0).astype(int)
    
    teams_list = teams_df.to_dict('records')
    
    # Calculate overview
    total_players = len(players_list)
    total_teams = len(teams_list)
    total_matches = int(teams_df['matches'].sum()) if 'matches' in teams_df.columns else len(df['match_id'].unique()) if 'match_id' in df.columns else 0
    total_goals = int(teams_df['goals_for'].sum()) if 'goals_for' in teams_df.columns else 0
    
    overview_data = {
        'total_players': total_players,
        'total_teams': total_teams,
        'total_matches': total_matches,
        'total_goals': total_goals,
        'avg_age': df['age'].mean() if 'age' in df.columns else 0
    }
    
    return players_list, teams_list, overview_data


@app.route('/')
def index():
    """Render the main dashboard"""
    return render_template('dashboard.html', 
                         players=json.dumps(players),
                         teams=json.dumps(teams),
                         overview=json.dumps(overview),
                         stage_goals=json.dumps(stage_goals),
                         position_order=json.dumps(POSITION_ORDER))


@app.route('/upload', methods=['POST'])
def upload_csv():
    """Handle CSV file upload"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'Please upload a CSV file'}), 400
        
        # Read CSV
        df = pd.read_csv(file)
        
        if df.empty:
            return jsonify({'error': 'CSV file is empty'}), 400
        
        # Process data
        players_list, teams_list, overview_data = process_csv_data(df)
        
        # Update global data
        global players, teams, overview
        players = players_list
        teams = teams_list
        overview = overview_data
        
        return jsonify({
            'success': True,
            'players': players_list,
            'teams': teams_list,
            'overview': overview_data,
            'message': f'Successfully loaded {len(players_list)} players from {len(teams_list)} teams'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/sample')
def load_sample():
    """Reset to sample data"""
    global players, teams, overview
    players = SAMPLE_PLAYERS.copy()
    teams = SAMPLE_TEAMS.copy()
    overview = SAMPLE_OVERVIEW.copy()
    return jsonify({
        'success': True,
        'players': players,
        'teams': teams,
        'overview': overview,
        'message': 'Loaded sample data'
    })


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)